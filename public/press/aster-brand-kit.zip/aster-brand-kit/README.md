# Aster brand assets

Static logo files for press, editorial, sponsor decks, and partner co-marketing.

## Files

| File | Use |
|------|-----|
| `aster-mark-lime.svg` / `.png` | Primary lime (#C7F542) — on dark backgrounds |
| `aster-mark-lime-deep.svg` / `.png` | Primary lime-deep (#4A6300) — on light backgrounds, AA-safe |
| `aster-mark-dark.svg` / `.png` | Mono dark (#181E15) — on white / mint backgrounds |
| `aster-mark-white.svg` / `.png` | Mono white knockout — on dark backgrounds |

PNG raster is 1024×1024 with a transparent canvas — composite onto whatever background you need.

## Brand colours

| Name | Hex | Use |
|------|-----|-----|
| Lime | `#C7F542` | Primary action / accent on dark |
| Lime deep | `#4A6300` | Primary action / accent on light |
| Dark | `#181E15` | Background + body text on light |
| Mint | `#DCEEEB` | Background on dark + soft surfaces |

## Wordmark

The Aster wordmark is set in **Barlow Condensed**, weight 700, uppercase, with `letter-spacing: 0.04em`. Pair the wordmark with the mark for the full lockup, mark-left, wordmark-right, vertically centred.

## Need something else?

Lockup-with-wordmark files, alternate proportions, the Aster typeface stack, brand voice notes — email [press@astertrack.app](mailto:press@astertrack.app) and we'll send what fits your format.

## Regenerating

These files are derived from the canonical SVG path data in `frontend/src/components/AsterLogo.tsx`. If the logo ever changes, update the `PATHS` array in `build.mjs` and re-run:

```bash
node frontend/public/press/build.mjs
```

Don't hand-edit the generated SVGs or PNGs.
