# Aster — brand quick reference

- Wordmark: ASTER, Barlow Condensed, uppercase, positive tracking.
- Mark: the 4-petal geometric flower (see /logos, SVG + PNG in four colourways).
- Colours: dark #181E15 · lime #C7F542 (accent under dark text only; use
  lime-deep #4A6300 for accent text on light) · mint #DCEEEB · stone #F0F4F4 ·
  gold #F2C94C.
- Type: Barlow (body) + Barlow Condensed (display, uppercase). Google Fonts.
- Voice: warm, plain-spoken, British English. Headlines end in a period.
- Photography: real events, golden hour, motion — no posed stock.
- Company: Manual Focus Ltd (UK). Contact: press@astertrack.app
